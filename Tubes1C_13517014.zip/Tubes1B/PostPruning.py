import pandas as pd
import numpy as np
import Function as f
import FitC45 as fc45
from DecisionTree import DecisionTree

# Pruning conducted after decision tree completely built.
# def postPruning():
#     # Build a tree
#     decisionTree = DecisionTree()
#     decisionTree = fc45.fit.result

#     # Set rules to prune the tree
#     treeAccuracy = 0.8

    # Searching for nodes and childern
    



# result = DecisionTree()
# print(result)




